function myAlert(msg){
    if(confirm("Are you sure you want to display the message?????")){
        alert(msg);
    }
    else{
        alert("Message not Displayed as User Canceled Operation")
    }
}